#!/bin/bash
# Created by Jocalinux
# Do you need a help? jocalinux@gmail.com

check-packages(){
for packages in git ansible ansible-playbook nmap cat awk date ;
do
	check=`whereis ${packages} | awk -F ' ' '{ print $2 }'`
	if [ "${check}" == '' ] ; then {
		echo -e $"Binary not installed: \033[31m${packages}\033[m"
		echo -e $"Try: \033[33myum install ${packages}\033[m (or 'yum search ${packages}')"
		echo "----------------------------------------------------------------------------"
	}
	else {
		echo -e $"Binary is installed: \033[32m${check}\033[m"
	}
	fi
done
}

# Exec func
check-packages
