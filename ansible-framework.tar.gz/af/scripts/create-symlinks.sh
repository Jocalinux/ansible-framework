#!/bin/bash
# Created by Jocalinux
# Do you need a help? jocalinux@gmail.com

create-symlinks(){
for script in ansible-run ansible-sshkey ansible-template ansible-control ;
do
	# Check scripts
	if [ -f "/af/scripts/${script}" ] ; then {
		# Remove symlinks
		rm=`whereis rm | awk -F ' ' '{ print $2 }'`
		${rm} -f /usr/bin/${script}
	
		# Create symlinks
		sym=`whereis ln | awk -F ' ' '{ print $2 }'`
		${sym} -s /af/scripts/${script} /usr/bin/${script}
		if [ $? == "0" ] ; then {
			echo -e $"Created symlink: \033[32m/usr/bin/${script}\033[m"
			whereis ${script}
			echo "------------------------------------------------------"
		}
		else {
			echo -e $"Failure to create a symlink for: \033[32m/usr/bin/${script}\033[m"
		}
		fi
	}
	else {
		echo -e $"The script: \033[31m/af/scripts/${script}\033[m not exist! Aborting script ...:("
		exit 1
	}
	fi

	  
done
}

# Exec func
create-symlinks
